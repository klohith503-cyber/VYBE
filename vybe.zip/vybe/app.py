
import os
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user,
    logout_user, login_required, current_user
)
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import or_

app = Flask(__name__)

# ---------------- CONFIGURATION ----------------

app.config["SECRET_KEY"] = os.environ.get(
    "SECRET_KEY", "vybe-development-secret-change-before-deployment"
)

db_url = os.environ.get("DATABASE_URL", "sqlite:///vybe.db")

if db_url.startswith("postgres://"):
    db_url = db_url.replace("postgres://", "postgresql+psycopg://", 1)
elif db_url.startswith("postgresql://") and "+psycopg" not in db_url:
    db_url = db_url.replace("postgresql://", "postgresql+psycopg://", 1)

app.config["SQLALCHEMY_DATABASE_URI"] = db_url
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

login_manager = LoginManager(app)
login_manager.login_view = "login"


# ---------------- DATABASE MODELS ----------------

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), unique=True, nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    bio = db.Column(db.String(250), default="")
    points = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)


class Post(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    body = db.Column(db.String(2000), nullable=False)
    image_url = db.Column(db.String(1000), default="")
    mood = db.Column(db.String(30), default="✨")
    anonymous = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    author = db.relationship("User")
    likes = db.relationship("Like", backref="post", cascade="all, delete-orphan")
    comments = db.relationship("Comment", backref="post", cascade="all, delete-orphan")


class Like(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    post_id = db.Column(db.Integer, db.ForeignKey("post.id"))

    __table_args__ = (
        db.UniqueConstraint("user_id", "post_id"),
    )


class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    post_id = db.Column(db.Integer, db.ForeignKey("post.id"))
    body = db.Column(db.String(600))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    author = db.relationship("User")


class Follow(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    follower_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    followed_id = db.Column(db.Integer, db.ForeignKey("user.id"))

    __table_args__ = (
        db.UniqueConstraint("follower_id", "followed_id"),
    )


class Story(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    body = db.Column(db.String(300))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    author = db.relationship("User")


class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    receiver_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    body = db.Column(db.String(2000))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    sender = db.relationship("User", foreign_keys=[sender_id])


class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    actor_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    message = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)

    actor = db.relationship("User", foreign_keys=[actor_id])


class Circle(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(70), unique=True)
    description = db.Column(db.String(300))
    creator_id = db.Column(db.Integer, db.ForeignKey("user.id"))

    creator = db.relationship("User")


class CircleMember(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    circle_id = db.Column(db.Integer, db.ForeignKey("circle.id"))
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))

    __table_args__ = (
        db.UniqueConstraint("circle_id", "user_id"),
    )


class Pulse(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    question = db.Column(db.String(300))
    option_a = db.Column(db.String(80))
    option_b = db.Column(db.String(80))
    option_c = db.Column(db.String(80))
    creator_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    creator = db.relationship("User")


class PulseVote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pulse_id = db.Column(db.Integer, db.ForeignKey("pulse.id"))
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    option_index = db.Column(db.Integer)

    __table_args__ = (
        db.UniqueConstraint("pulse_id", "user_id"),
    )


class Report(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    post_id = db.Column(db.Integer, db.ForeignKey("post.id"))
    reporter_id = db.Column(db.Integer, db.ForeignKey("user.id"))
    reason = db.Column(db.String(300))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


# ---------------- COMMON FUNCTIONS ----------------

def notify(recipient_id, message):
    if current_user.is_authenticated and recipient_id != current_user.id:
        db.session.add(Notification(
            recipient_id=recipient_id,
            actor_id=current_user.id,
            message=message
        ))


def get_unread():
    if not current_user.is_authenticated:
        return 0

    return Notification.query.filter_by(
        recipient_id=current_user.id,
        is_read=False
    ).count()


def page(name, **kwargs):
    return render_template(
        "page.html",
        page=name,
        unread=get_unread(),
        **kwargs
    )


# ---------------- HOME FEED ----------------

@app.route("/")
def home():

    if current_user.is_authenticated:
        followed = [
            f.followed_id
            for f in Follow.query.filter_by(
                follower_id=current_user.id
            ).all()
        ]

        posts = Post.query.filter(
            Post.anonymous == False,
            Post.user_id.in_(followed + [current_user.id])
        ).order_by(Post.created_at.desc()).limit(40).all()

    else: 
        posts = Post.query.filter_by(
            anonymous=False
        ).order_by(Post.created_at.desc()).limit(40).all()

    stories = Story.query.filter(
        Story.created_at >= datetime.utcnow() - timedelta(hours=24)
    ).order_by(Story.created_at.desc()).limit(20).all()

    return page("home", posts=posts, stories=stories)


# ---------------- REGISTRATION ----------------

@app.route("/register", methods=["GET", "POST"])
def register():

    if current_user.is_authenticated:
        return redirect(url_for("home"))

    if request.method == "POST":

        username = request.form.get("username", "").strip().lower()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        import re

        if not re.fullmatch(r"[a-z0-9_]{3,30}", username):
            flash("Username must contain 3–30 letters, numbers or underscores.", "error")

        elif "@" not in email or len(email) > 160:
            flash("Enter a valid email address.", "error")

        elif len(password) < 8:
            flash("Password must have at least 8 characters.", "error")

        elif User.query.filter(
            or_(User.username == username, User.email == email)
        ).first():
            flash("Username or email already exists.", "error")

        else:
            user = User(username=username, email=email)
            user.set_password(password)

            db.session.add(user)
            db.session.commit()

            login_user(user)
            flash("Welcome to VYBE!", "success")

            return redirect(url_for("home"))

    return page("register")


# ---------------- LOGIN ----------------

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        identity = request.form.get("identity", "").strip().lower()
        password = request.form.get("password", "")

        user = User.query.filter(
            or_(
                User.username == identity,
                User.email == identity
            )
        ).first()

        if user and user.check_password(password):

            login_user(user)
            flash("Welcome back!", "success")

            return redirect(url_for("home"))

        flash("Invalid login details.", "error")

    return page("login")


@app.route("/logout")
@login_required
def logout():

    logout_user()
    return redirect(url_for("home"))


# ---------------- CREATE POSTS ----------------

@app.route("/post", methods=["POST"])
@login_required
def create_post():

    body = request.form.get("body", "").strip()
    image_url = request.form.get("image_url", "").strip()
    mood = request.form.get("mood", "✨")

    if not body or len(body) > 2000:
        flash("Write a post between 1 and 2,000 characters.", "error")

    elif image_url and not image_url.startswith(("https://", "http://")):
        flash("Enter a valid image URL.", "error")

    else:

        post = Post(
            user_id=current_user.id,
            body=body,
            image_url=image_url,
            mood=mood
        )

        current_user.points += 5

        db.session.add(post)
        db.session.commit()

        flash("Your post is live! +5 Creator Points.", "success")

    return redirect(url_for("home"))


# ---------------- LIKES ----------------

@app.route("/like/<int:post_id>", methods=["POST"])
@login_required
def like(post_id):

    post = db.get_or_404(Post, post_id)

    existing = Like.query.filter_by(
        user_id=current_user.id,
        post_id=post.id
    ).first()

    if existing:
        db.session.delete(existing)

    else:
        db.session.add(Like(
            user_id=current_user.id,
            post_id=post.id
        ))

        notify(post.user_id, "liked your post")
        current_user.points += 1

    db.session.commit()

    return redirect(request.referrer or url_for("home"))


# ---------------- COMMENTS ----------------

@app.route("/comment/<int:post_id>", methods=["POST"])
@login_required
def comment(post_id):

    post = db.get_or_404(Post, post_id)
    body = request.form.get("body", "").strip()

    if body and len(body) <= 600:

        db.session.add(Comment(
            user_id=current_user.id,
            post_id=post.id,
            body=body
        ))

        notify(post.user_id, "commented on your post")
        db.session.commit()

    return redirect(request.referrer or url_for("home"))


# ---------------- EXPLORE ----------------

@app.route("/explore")
def explore():

    term = request.args.get("q", "").strip()

    if term:
        users = User.query.filter(
            User.username.ilike(f"%{term}%")
        ).limit(30).all()
    else:
        users = User.query.order_by(
            User.points.desc()
        ).limit(30).all()

    posts = Post.query.filter_by(
        anonymous=False
    ).order_by(Post.created_at.desc()).limit(30).all()

    return page(
        "explore",
        users=users,
        posts=posts,
        term=term
    )


# ---------------- USER PROFILE ----------------

@app.route("/u/<username>")
def profile(username):

    user = User.query.filter_by(
        username=username.lower()
    ).first_or_404()

    posts = Post.query.filter_by(
        user_id=user.id,
        anonymous=False
    ).order_by(Post.created_at.desc()).all()

    followers = Follow.query.filter_by(
        followed_id=user.id
    ).count()

    following_count = Follow.query.filter_by(
        follower_id=user.id
    ).count()

    is_following = False

    if current_user.is_authenticated:
        is_following = bool(Follow.query.filter_by(
            follower_id=current_user.id,
            followed_id=user.id
        ).first())

    return page(
        "profile",
        profile_user=user,
        posts=posts,
        followers=followers,
        following_count=following_count,
        is_following=is_following
    )


# ---------------- FOLLOW SYSTEM ----------------

@app.route("/follow/<int:user_id>", methods=["POST"])
@login_required
def follow(user_id):

    target = db.get_or_404(User, user_id)

    if target.id == current_user.id:
        abort(400)

    existing = Follow.query.filter_by(
        follower_id=current_user.id,
        followed_id=target.id
    ).first()

    if existing:
        db.session.delete(existing)

    else:
        db.session.add(Follow(
            follower_id=current_user.id,
            followed_id=target.id
        ))

        current_user.points += 2
        notify(target.id, "started following you")

    db.session.commit()

    return redirect(request.referrer or url_for(
        "profile", username=target.username
    ))


# ---------------- 24 HOUR STORIES ----------------

@app.route("/stories", methods=["POST"])
@login_required
def create_story():

    body = request.form.get("body", "").strip()

    if body and len(body) <= 300:

        db.session.add(Story(
            user_id=current_user.id,
            body=body
        ))

        db.session.commit()
        flash("Your 24-hour story is live!", "success")

    return redirect(url_for("home"))


# ---------------- ANONYMOUS CONFESSIONS ----------------

@app.route("/confess", methods=["GET", "POST"])
def confessions():

    if request.method == "POST":

        if not current_user.is_authenticated:
            return redirect(url_for("login"))

        body = request.form.get("body", "").strip()

        if body and len(body) <= 1200:

            db.session.add(Post(
                user_id=current_user.id,
                body=body,
                mood="🎭",
                anonymous=True
            ))

            db.session.commit()
            flash("Your confession is anonymous.", "success")

    posts = Post.query.filter_by(
        anonymous=True
    ).order_by(Post.created_at.desc()).limit(50).all()

    return page("confessions", posts=posts)


# ---------------- PRIVATE MESSAGES ----------------

@app.route("/inbox")
@login_required
def inbox():

    messages = Message.query.filter(
        or_(
            Message.sender_id == current_user.id,
            Message.receiver_id == current_user.id
        )
    ).order_by(Message.created_at.desc()).all()

    people_ids = set()

    for message in messages:
        if message.sender_id != current_user.id:
            people_ids.add(message.sender_id)
        if message.receiver_id != current_user.id:
            people_ids.add(message.receiver_id)

    people = User.query.filter(
        User.id.in_(people_ids)
    ).all() if people_ids else []

    return page("inbox", people=people)


@app.route("/chat/<int:user_id>")
@login_required
def chat(user_id):

    other = db.get_or_404(User, user_id)

    if other.id == current_user.id:
        abort(400)

    messages = Message.query.filter(
        or_(
            (Message.sender_id == current_user.id) &
            (Message.receiver_id == other.id),
            (Message.sender_id == other.id) &
            (Message.receiver_id == current_user.id)
        )
    ).order_by(Message.created_at.asc()).limit(200).all()

    return page(
        "chat",
        other=other,
        messages=messages
    )


@app.route("/message/<int:user_id>", methods=["POST"])
@login_required
def send_message(user_id):

    other = db.get_or_404(User, user_id)
    body = request.form.get("body", "").strip()

    if body and len(body) <= 2000:

        db.session.add(Message(
            sender_id=current_user.id,
            receiver_id=other.id,
            body=body
        ))

        notify(other.id, "sent you a message")
        db.session.commit()

    return redirect(url_for("chat", user_id=other.id))


# ---------------- NOTIFICATIONS ----------------

@app.route("/notifications")
@login_required
def notifications():

    items = Notification.query.filter_by(
        recipient_id=current_user.id
    ).order_by(Notification.created_at.desc()).limit(60).all()

    for item in items:
        item.is_read = True

    db.session.commit()

    return page("notifications", items=items)


# ---------------- VYBE CIRCLES ----------------

@app.route("/circles", methods=["GET", "POST"])
@login_required
def circles():

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        description = request.form.get("description", "").strip()

        if 3 <= len(name) <= 70 and not Circle.query.filter_by(name=name).first():

            circle = Circle(
                name=name,
                description=description[:300],
                creator_id=current_user.id
            )

            db.session.add(circle)
            db.session.flush()

            db.session.add(CircleMember(
                circle_id=circle.id,
                user_id=current_user.id
            ))

            db.session.commit()
            flash("Your circle has been created!", "success")

        else:
            flash("Choose a unique circle name of 3–70 characters.", "error")

    circles_list = Circle.query.order_by(Circle.id.desc()).all()

    memberships = {
        item.circle_id
        for item in CircleMember.query.filter_by(
            user_id=current_user.id
        ).all()
    }

    return page(
        "circles",
        circles=circles_list,
        memberships=memberships
    )


@app.route("/circle/<int:circle_id>/join", methods=["POST"])
@login_required
def join_circle(circle_id):

    circle = db.get_or_404(Circle, circle_id)

    existing = CircleMember.query.filter_by(
        circle_id=circle.id,
        user_id=current_user.id
    ).first()

    if existing:
        db.session.delete(existing)
    else:
        db.session.add(CircleMember(
            circle_id=circle.id,
            user_id=current_user.id
        ))

    db.session.commit()

    return redirect(url_for("circles"))


# ---------------- DAILY PULSE ----------------

@app.route("/pulse", methods=["GET", "POST"])
@login_required
def pulse():

    if request.method == "POST":

        question = request.form.get("question", "").strip()
        a = request.form.get("a", "").strip()
        b = request.form.get("b", "").strip()
        c = request.form.get("c", "").strip()

        if question and a and b and c:

            db.session.add(Pulse(
                question=question,
                option_a=a,
                option_b=b,
                option_c=c,
                creator_id=current_user.id
            ))

            db.session.commit()
            flash("Your Pulse is published!", "success")

        else:
            flash("Fill in the question and all three options.", "error")

    polls = Pulse.query.order_by(
        Pulse.created_at.desc()
    ).limit(40).all()

    voted = {
        v.pulse_id
        for v in PulseVote.query.filter_by(
            user_id=current_user.id
        ).all()
    }

    return page(
        "pulse",
        polls=polls,
        voted=voted
    )


@app.route("/vote/<int:pulse_id>", methods=["POST"])
@login_required
def vote(pulse_id):

    poll = db.get_or_404(Pulse, pulse_id)

    try:
        option = int(request.form.get("option", -1))
    except ValueError:
        option = -1

    existing = PulseVote.query.filter_by(
        pulse_id=poll.id,
        user_id=current_user.id
    ).first()

    if option in [0, 1, 2] and not existing:

        db.session.add(PulseVote(
            pulse_id=poll.id,
            user_id=current_user.id,
            option_index=option
        ))

        db.session.commit()

    return redirect(url_for("pulse"))


# ---------------- REPORT SYSTEM ----------------

@app.route("/report/<int:post_id>", methods=["POST"])
@login_required
def report(post_id):

    db.get_or_404(Post, post_id)

    db.session.add(Report(
        post_id=post_id,
        reporter_id=current_user.id,
        reason=request.form.get("reason", "Review requested")[:300]
    ))

    db.session.commit()

    flash("Report submitted for review.", "success")

    return redirect(request.referrer or url_for("home"))


# ---------------- ADMIN DASHBOARD ----------------

def is_admin():
    return (
        current_user.is_authenticated and
        current_user.username == os.environ.get("ADMIN_USERNAME", "admin")
    )


@app.route("/admin")
@login_required
def admin():

    if not is_admin():
        abort(403)

    reports = Report.query.order_by(
        Report.created_at.desc()
    ).all()

    return page(
        "admin",
        reports=reports,
        users_count=User.query.count(),
        posts_count=Post.query.count()
    )


@app.route("/admin/report/<int:report_id>/dismiss", methods=["POST"])
@login_required
def dismiss_report(report_id):

    if not is_admin():
        abort(403)

    report = db.get_or_404(Report, report_id)

    db.session.delete(report)
    db.session.commit()

    return redirect(url_for("admin"))


# ---------------- HEALTH CHECK ----------------

@app.route("/health")
def health():

    try:
        db.session.execute(db.text("SELECT 1"))
        return jsonify(status="ok", database="connected"), 200

    except Exception:
        return jsonify(status="error", database="unavailable"), 503


# ---------------- ERROR PAGES ----------------

@app.errorhandler(403)
def forbidden(error):
    return page("error", code=403,
                message="You don't have permission to access this page."), 403


@app.errorhandler(404)
def not_found(error):
    return page("error", code=404,
                message="The page you requested was not found."), 404


# ---------------- DATABASE INITIALIZATION ----------------

with app.app_context():
    db.create_all()

    if Circle.query.count() == 0:
        system_user = User(
            username="vybe_system",
            email="system@vybe.local"
        )
        system_user.set_password("disabled-system-account-password")

        db.session.add(system_user)
        db.session.flush()

        starter_circles = [
            ("Creators Lab", "Creative ideas, designs and experiments."),
            ("Code & Coffee", "Programming and developer discussions."),
            ("Campus Connect", "Students, learning and opportunities."),
            ("Mindful Moments", "Positive thoughts and daily motivation.")
        ]

        for name, description in starter_circles:
            db.session.add(Circle(
                name=name,
                description=description,
                creator_id=system_user.id
            ))

        db.session.commit()


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=int(os.environ.get("PORT", 5000)),
        debug=False
    )
